<script>
  let customerList = [];
  let customer = {};
  
  let productList = [];
  let cartItemList =  [];
  let total;

  let baseUrl = "http://127.0.0.1:8000/api";
  function getCustomerInfo(e) {
    let url = baseUrl + '/get-customer-by-phone/' + e.target.value;
    console.log('url=', url);
    fetch(url).then(resp => resp.json()).then(result => customer = result);
  }
  async function updateCustomerList(e) {
    let phone = e.target.value;
    let resp = await fetch(baseUrl + "/search-customer?phone=" + (phone ?? ""));
    customerList = await resp.json();
  }

  // ======================================= Cart =======================================================

  function updateTotal() {
    total = 0;
    cartItemList
      .filter(x => x.product_code)
      .forEach(x => total += x.sub_total);
  }

  function addCartItem() {
    cartItemList = [...cartItemList, {qty:1}];
    updateTotal();
  }

  function updateCartItemQty(index, qty) {
    let newCartItemList = [...cartItemList];
    let cartItem = newCartItemList[index];
    cartItem.qty = qty;
    if(cartItem.product_code) {
      cartItem.sub_total = cartItem.price * qty;
    }
    cartItemList = newCartItemList;
    updateTotal();
  }

  async function updateProductList(e) {
    let code = e.target.value;
    let resp = await fetch(baseUrl + "/search-product?code=" + (code ?? ""));
    productList = await resp.json();
  }

  async function getProductInfo(e, index) {
    let code = e.target.value;
    let resp = await fetch(baseUrl + "/get-product-by-code/" + (code ?? ""));
    let selectedProduct = await resp.json();
    let newCartItemList = [...cartItemList];
    
    let cartItem = newCartItemList[index];
    cartItem.product_code = selectedProduct.code;
    cartItem.product_name = selectedProduct.name;
    cartItem.price = cartItem.sub_total = selectedProduct.price;
    cartItem.qty = 1;

    cartItemList = newCartItemList;
    updateTotal();
  }

  function deleteCartItem(index) {
    let newCartItemList = [...cartItemList];
    newCartItemList.splice(index, 1);
    cartItemList = newCartItemList;
    updateTotal();
  }
</script>
<main>
  <div class="container mt-3">
    <h4>Thông tin khách hàng</h4>
    <hr/>
    <table class="table">
      <tbody>
        <tr>
          <th style="width:30%">Số điện thoại:</th>
          <td>
            <input class="form-control" list="customerList"
              autocomplete="off"
              on:keyup={updateCustomerList}
              on:change={getCustomerInfo}
              >
            <datalist id="customerList">
              {#each customerList as customer}
                <option value={customer.phone}>
              {/each}
            </datalist>
          </td>
        </tr>
        <tr>
          <th>Họ tên khách hàng:</th>
          <td>{customer.fullname ?? ""}</td>
        </tr>
        <tr>
          <th>Địa chỉ:</th>
          <td>{customer.address ?? ""}</td>
        </tr>
      </tbody>
    </table>
    <br/>
    <h4>Danh sách các mặt hàng mua</h4>
    <hr/>
    <button class="btn btn-sm btn-primary float-end" on:click={addCartItem}>Thêm</button>
    <table class="table">
      <thead>
        <tr>
          <th style="width:20%">Mã SP</th>
          <th style="width:25%">Tên SP</th>
          <th style="width:20%">Đơn giá</th>
          <th style="width:10%">Số lượng</th>
          <th style="width:20%">Thành tiền</th>
          <th style="width:5%"></th>
        </tr>
      </thead>
      <tbody>
        {#each cartItemList as cartItem, index}
          <tr>
            <td>
              <input class="form-control" list={`productList_${index}`} name="customer"
                autocomplete="off"
                on:keyup={updateProductList}
                on:change={(e) => getProductInfo(e, index)}
              >
              <datalist id={`productList_${index}`}>
                {#each productList as product}
                  <option value={product.code}>
                {/each}
              </datalist>
            </td>
            <td>{cartItem.product_name ?? ""}</td>
            <td>{cartItem.price ?? ""}</td>
            <td>
              <input class="form-control" type="number" min="1" value={cartItem.qty}
                on:change={e => updateCartItemQty(index, e.target.value)}
              />
            </td>
            <td>{cartItem.sub_total ?? ""}</td>
            <td>
              <button class="btn btn-sm btn-danger" on:click={() => deleteCartItem(index)}>
                Xoá
              </button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
    <div>Tổng số tiền: <span>{total ?? ""}</span></div>
  </div>
</main>