<script>
  function btnClick() {
    alert("Hello");
  }
</script>

<main>
	<div class="container mt-3">
		<button 
      class="btn btn-primary"
      on:click={btnClick}
    >OK</button>
	</div>
</main>